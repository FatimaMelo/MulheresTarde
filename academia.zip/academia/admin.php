<?php
  require_once 'head.php';

    //session_start();
    ob_start();
  

?>  

<a href="frmaluno.php"><button type="submit">Cadastro de Aluno</button></a>

<a href="relalunos.php"><button type="submit">Relatório de Alunos</button></a>